import java.util.ArrayList;
import java.util.Scanner;

public class ParcAuto {
    private static ArrayList<Vehicule> vehicules = new ArrayList<>();
    private static ArrayList<Clients> clients = new ArrayList<>();
    private static Scanner auto = new Scanner(System.in);

    public static void main(String[] args) {
        int choix;

        do {
            System.out.println("\n BIENVENUE: MENU DU PARC AUTOMOBLE");
            System.out.println("Qu'est ce qu'on peut faire pour vous ?");
            System.out.println("(1) Ajouter un nouveau véhicule: ");
            System.out.println("(2) Ajouter un nouveau client");
            System.out.println("(3) Louer un vehicule: ");
            System.out.println("(4) Retourner un vehicule: ");
            System.out.println("(5) Liste des véhicules disponibles: ");
            System.out.println("(6) Liste des véhicules loués");
            System.out.println("(7) Quitter");
            System.out.print("veillez Choisir une option: ");
            choix = auto.nextInt();  

            switch (choix) {
                case 1: {
                    ajouterVehicule();
                    break;
                }
                case 2: {
                    ajouterClient();
                    break;
                }
                case 3: {
                    louerVehicule();
                    break;
                }
                case 4: {
                    retournerVehicule();
                    break;
                }
                case 5: {
                    listerVehicules("disponible");
                    break;
                }
                case 6: {
                    listerVehicules("loué");
                    break;
                }
                case 7: {
                    
                    break;
                }
                default: {
                    System.out.println("Option invalide, veuillez réessayer.");
                    break;
                }
            }
    
        } while (choix != 7);
    }
 //methode pour ajouter un vehicule a l'interieur de laquelle nous aurons a faire deux choix et saisir les informations utiles;
    private static void ajouterVehicule() {
        System.out.println("\nAjouter un nouveau véhicule");
        System.out.print("Type de véhicule (1 pour Voiture, 2 pour Camion) : ");
        int type = auto.nextInt();
        auto.nextLine();

        System.out.print("Immatriculation : ");
        String immatriculation = auto.nextLine();
        System.out.print("Marque : ");
        String marque = auto.nextLine();
        System.out.print("Modèle : ");
        String modele = auto.nextLine();
        System.out.print("Année de mise en service : ");
        int annee = auto.nextInt();
        System.out.print("Kilométrage : ");
        int kilometrage = auto.nextInt();
//dans le cas ou l'on fait le 1er choix c'est a dire celui de la voiture;
        if (type == 1) {
            System.out.print("Nombre de places : ");
            int nombreDePlace = auto.nextInt();
            auto.nextLine();
            System.out.print("Type de carburant : ");
            String typeDeCarburant = auto.nextLine();
            vehicules.add(new Voiture(immatriculation, marque, modele, annee, kilometrage, nombreDePlace, typeDeCarburant));
        } //dans le cas ou l'on fait le 2eme choix c'est a dire celui du camion;
        else if (type == 2) {
            System.out.print("Capacité de charge : ");
            double capaciteCharge = auto.nextDouble();
            System.out.print("Nombre d'essieux : ");
            int nombreEssieux = auto.nextInt();
            vehicules.add(new Camion(immatriculation, marque, modele, annee, kilometrage, capaciteCharge, nombreEssieux));
        } else {
            System.out.println("Type de véhicule invalide.");
        }
    }
//methode pour ajouter un client a la liste;
    private static void ajouterClient() {
        System.out.println("\nAjouter un nouveau client");
        System.out.println("Nom : ");
        String nom = auto.nextLine();
        System.out.print("Prénom : ");
        String prenom = auto.nextLine();
        System.out.print("Numéro de permis de conduire : ");
        String numeroPermis = auto.nextLine();
        System.out.print("Numéro de téléphone : ");
        int numeroTelephone = auto.nextInt();
        clients.add(new Clients(nom, prenom, numeroPermis, numeroTelephone));
    }
//methode de location de vehicule;
    private static void louerVehicule() {
        System.out.println("\nLouer un véhicule à un client");
        System.out.print("Immatriculation du véhicule : ");
        String immatriculation = auto.nextLine();
        System.out.print("Numéro de permis du client : ");
        String numeroPermis = auto.nextLine();

        Vehicule vehicule = trouverVehicule(immatriculation);
        Clients client = trouverClient(numeroPermis);
//condition de recherche sur un vehicule ou un client;
        if (vehicule == null) {
            System.out.println("Véhicule non reconnu");
            return;
        }
        if (client == null) {
            System.out.println("Client introuvable");
            return;
        }

        try {
            vehicule.louer(client.numeroPermisDeConduire);
            System.out.println("Felicitation vous venez de louer un vehicule");
        } catch (VehiculeIndisponibleException | ClientNonAutoriseException e) {
            System.out.println("Erreur de location : " + e.getMessage());
        }
    }
//methode de retour de vehicule loué;
    private static void retournerVehicule() {
        System.out.println("\nRetourner un vehicule");
        System.out.print("Immatriculation du vehicule : ");
        String immatriculation = auto.nextLine();

        Vehicule vehicule = trouverVehicule(immatriculation);

        if (vehicule != null && vehicule.statut.equals("loué")) {
            vehicule.retourner();
            System.out.println("Le client a retourné la vehicule avec succès");
        } else {
            System.out.println("Le vehicule est deja disponible ou introuvable");
        }
    }
//methode d'affichage de la liste des vehicules
    private static void listerVehicules(String statutDeRecherche) {
        System.out.println("\nListe des véhicules " + statutDeRecherche + "s :");
        for (Vehicule vehicule : vehicules) {
            if (vehicule.statut.equals(statutDeRecherche)) {
                System.out.println(vehicule);
            }
        }
    }

    private static Vehicule trouverVehicule(String immatriculation) {
        for (Vehicule vehicule : vehicules) {
            if (vehicule.immatriculation.equals(immatriculation)) {
                return vehicule;
            }
        }
        return null;
    }

    private static Clients trouverClient(String numeroPermis) {
        for (Clients client : clients) {
            if (client.numeroPermisDeConduire.equals(numeroPermis)) {
                return client;
            }
        }
        return null;
    }
}

// Interface Louable;
interface Louable {
    void louer(String typePermis) throws VehiculeIndisponibleException, ClientNonAutoriseException;
    void retourner();
    double calculerPrixLocation();
}

// Classe mere vehicule;
abstract class Vehicule implements Louable {
    protected String immatriculation;
    protected String marque;
    protected String modele;
    protected int anneeDeMiseEnService;
    protected int kilometrage;
    protected String statut;
//constructeur de la classe mere;
    public Vehicule(String immatriculation, String marque, String modele, int anneeDeMiseEnService, int kilometrage) {
        this.immatriculation = immatriculation;
        this.marque = marque;
        this.modele = modele;
        this.anneeDeMiseEnService = anneeDeMiseEnService;
        this.kilometrage = kilometrage;
        this.statut = "disponible";
    }
//methode pour calculer le prix de la location definie dans interface;
    public abstract double calculerPrixLocation();
//methode pour pouvoir retourner un vehicule;
    public void retourner() {
        statut = "disponible";
    }
 //pour afiicher les details du vehicule choisi par l'utilisateur;
    public String toString() {
        return immatriculation + " " + marque + " " + modele + ", Année : " + anneeDeMiseEnService + ", Kilométrage : " + kilometrage + ", Statut : " + statut;
    }
//methode pour verifier si le permis est valide ou non;
    protected boolean verifierPermis(String typeDePermis) {
        return typeDePermis.equals("A")|| typeDePermis.equals("B") || typeDePermis.equals("C");
    }
}

// Classe Voiture fille voiture qui herite de certains attributs de vehicle;
class Voiture extends Vehicule {
    //intialisation de du prix de location pour une voiture;
    private static final double tarifV = 5000;
    private int nombreDePlace;
    private String typeDeCarburant;
//constructeur;
    public Voiture(String immatriculation, String marque, String modele, int anneeDeMiseEnService, int kilometrage, int nombreDePlace, String typeDeCarburant) {
        super(immatriculation, marque, modele, anneeDeMiseEnService, kilometrage);
        this.nombreDePlace = nombreDePlace;
        this.typeDeCarburant = typeDeCarburant;
    }

    @Override
    public double calculerPrixLocation() {
        return tarifV;
    }

    public void louer(String typePermis) throws VehiculeIndisponibleException, ClientNonAutoriseException {
        if (statut.equals("loué")) {
            throw new VehiculeIndisponibleException("Le véhicule est déjà loué.");
        }
        statut = "loué";
    }
}

// Classe fille camion qui herite toujours de vehicule;
class Camion extends Vehicule {
    //initialisation du prix de location pour un camion;
    private static final double tarifC = 10000;
    private double capaciteCharge;
    private int nombreEssieux;
//contructeur;
    public Camion(String immatriculation, String marque, String modele, int anneeDeMiseEnService, int kilometrage, double capaciteCharge, int nombreEssieux) {
        super(immatriculation, marque, modele, anneeDeMiseEnService, kilometrage);
        this.capaciteCharge = capaciteCharge;
        this.nombreEssieux = nombreEssieux;
    }

    @Override
    //prix location pour un vehicule(polymorphisme);
    public double calculerPrixLocation() {
        return tarifC * capaciteCharge;
    }
//methode de loction de vehicule;
    public void louer(String typePermis) throws VehiculeIndisponibleException, ClientNonAutoriseException {
        if (statut.equals("loué")) {
            throw new VehiculeIndisponibleException("Le véhicule est déjà loué.");
        }
        statut = "loué";
    }
}

// Classe Client;
class Clients {
    String nom;
    String prenom;
    String numeroPermisDeConduire;
    int numeroTelephone;
//constructeur;
    public Clients(String nom, String prenom, String numeroPermisDeConduire, int numeroTelephone) {
        this.nom = nom;
        this.prenom = prenom;
        this.numeroPermisDeConduire = numeroPermisDeConduire;
        this.numeroTelephone = numeroTelephone;
    }
}

// Exceptions 
class VehiculeIndisponibleException extends Exception {
    public VehiculeIndisponibleException(String message) {
        super(message);
    }
}
//exception
class ClientNonAutoriseException extends Exception {
    public ClientNonAutoriseException(String message) {
        super(message);
    }
}
